package com.bereton;

import com.bereton.gui.ClickGUI;
import com.bereton.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class BeretonClient implements ClientModInitializer {

    public static BeretonClient INSTANCE;
    public static ModuleManager moduleManager;
    public static ClickGUI clickGUI;

    private static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;

        moduleManager = new ModuleManager();
        moduleManager.init();

        clickGUI = new ClickGUI();

        // Right Shift key binding
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bereton.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.bereton"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(clickGUI);
                } else if (client.currentScreen instanceof ClickGUI) {
                    client.setScreen(null);
                }
            }
        });
    }

    public static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }
}
