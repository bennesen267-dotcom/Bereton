package com.bereton.modules.combat;

import com.bereton.BeretonClient;
import com.bereton.module.Category;
import com.bereton.module.Module;
import com.bereton.module.settings.BooleanSetting;
import com.bereton.module.settings.EnumSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class Aura extends Module {

    // ─── Rotation mode ───────────────────────────────────────────────
    public enum RotationMode { LEGIT, POLARAC }

    public final EnumSetting<RotationMode> rotations =
            register(new EnumSetting<>("Rotations", RotationMode.LEGIT));

    // ─── Toggles ─────────────────────────────────────────────────────
    public final BooleanSetting onlyWeapon =
            register(new BooleanSetting("Only Weapon", true));
    public final BooleanSetting clientLook =
            register(new BooleanSetting("Client Look", false));
    public final BooleanSetting onlyCrits =
            register(new BooleanSetting("Only Crits", true));
    public final BooleanSetting shieldBreaker =
            register(new BooleanSetting("Shield Breaker", true));
    public final BooleanSetting wallDetect =
            register(new BooleanSetting("Wall Detect", true));
    public final BooleanSetting focus =
            register(new BooleanSetting("Focus", false));
    public final BooleanSetting track =
            register(new BooleanSetting("Track", false));

    // ─── Internal state ───────────────────────────────────────────────
    private LivingEntity target         = null;
    private float         serverYaw     = 0f;
    private float         serverPitch   = 0f;
    private int           shieldTimer   = 0;
    private boolean       wasAxe        = false;
    private int           prevSlot      = -1;

    private static final Random RNG = new Random();

    public Aura() {
        super("Aura", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        // Release focus lock when toggled off — this is the only trigger that clears focus
        target = null;
        shieldTimer = 0;
        // Restore weapon slot if we swapped for shield breaker
        restorePrevSlot();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = BeretonClient.mc();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        PlayerEntity player = mc.player;

        // Only Weapon check — skip tick if not holding a weapon
        if (onlyWeapon.isEnabled() && !isWeapon(player.getMainHandStack().getItem())) {
            return;
        }

        // ─── Target selection ─────────────────────────────────────────
        LivingEntity nextTarget = selectTarget(mc, player);

        if (nextTarget == null) {
            if (!focus.isEnabled()) target = null;
            // No valid target this tick
            shieldTimer = 0;
            restorePrevSlot();
            return;
        }

        // Focus: once locked, keep the same target until aura is toggled
        if (focus.isEnabled() && target != null && target.isAlive() && !target.isRemoved()) {
            // keep existing target; only override if it died/removed
        } else {
            target = nextTarget;
        }

        // ─── Track: move player toward target ─────────────────────────
        if (track.isEnabled()) {
            Vec3d dir = target.getPos().subtract(player.getPos()).normalize();
            // Set movement input direction toward target regardless of camera
            double dx = dir.x;
            double dz = dir.z;
            // We calculate the yaw that points toward target and push forward
            float moveYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float delta = MathHelper.wrapDegrees(moveYaw - player.getYaw());
            // Shift input vector — MC uses forwardInput and sidewayInput in polar coords relative to player yaw
            // We override the move packet via MixinClientPlayerEntity, so here we store the desired yaw
            setMoveYaw(player, moveYaw);
        }

        // ─── Rotations ───────────────────────────────────────────────
        float[] rot = calculateRotation(player, target);
        float targetYaw   = rot[0];
        float targetPitch = rot[1];

        float finalYaw, finalPitch;

        switch (rotations.getValue()) {
            case LEGIT -> {
                // Smooth, realistic rotation with slight noise
                float smoothFactor = 0.35f + RNG.nextFloat() * 0.10f;
                finalYaw   = lerpAngle(serverYaw,   targetYaw,   smoothFactor);
                finalPitch = lerpAngle(serverPitch, targetPitch, smoothFactor);
                // Add tiny random noise to look human
                finalYaw   += (RNG.nextFloat() - 0.5f) * 0.4f;
                finalPitch += (RNG.nextFloat() - 0.5f) * 0.25f;
            }
            case POLARAC -> {
                // Polar AC bypass:
                //  - Clamp delta per tick to ≤35° (Polar's jitter threshold is ~40°)
                //  - No noise on the smooth path — Polar flags inconsistent jitter
                //  - Quantise to 0.05° steps (matches vanilla send precision)
                float maxDeltaYaw   = 32f;
                float maxDeltaPitch = 28f;
                float dy = MathHelper.wrapDegrees(targetYaw   - serverYaw);
                float dp = MathHelper.wrapDegrees(targetPitch - serverPitch);
                dy = MathHelper.clamp(dy, -maxDeltaYaw,   maxDeltaYaw);
                dp = MathHelper.clamp(dp, -maxDeltaPitch, maxDeltaPitch);
                finalYaw   = quantise(serverYaw   + dy);
                finalPitch = quantise(serverPitch + dp);
            }
            default -> {
                finalYaw   = targetYaw;
                finalPitch = targetPitch;
            }
        }

        serverYaw   = finalYaw;
        serverPitch = finalPitch;

        // Send server-side rotation packet
        sendRotation(mc, finalYaw, finalPitch, player.isOnGround());

        // Apply client-side camera if Client Look is enabled
        if (clientLook.isEnabled()) {
            player.setYaw(finalYaw);
            player.setPitch(finalPitch);
        }

        // ─── Shield Breaker ───────────────────────────────────────────
        if (shieldBreaker.isEnabled() && isUsingShield(target)) {
            swapToAxe(mc, player);
        } else if (!isUsingShield(target)) {
            restorePrevSlot();
            wasAxe = false;
        }

        // ─── Only Crits ───────────────────────────────────────────────
        if (onlyCrits.isEnabled()) {
            // Must be on ground and not in water to get a crit
            if (player.isOnGround() && !player.isTouchingWater() && !player.isInLava()) {
                // Jump to get crit on next tick
                player.jump();
                return; // wait for next tick when falling
            }
            // If we're falling (negative velocity) we can crit
            boolean isFalling = player.getVelocity().y < -0.0001;
            if (!isFalling) return;
        }

        // ─── Attack ───────────────────────────────────────────────────
        // Check cooldown — only attack at full cooldown to maximise damage
        if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    // ─── Target selection ─────────────────────────────────────────────
    private LivingEntity selectTarget(MinecraftClient mc, PlayerEntity player) {
        List<LivingEntity> candidates = new ArrayList<>();
        double range = 4.5;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (le == player) continue;
            if (!le.isAlive() || le.isRemoved()) continue;
            if (!(le instanceof PlayerEntity)) continue; // only target players
            if (le.distanceTo(player) > range) continue;

            if (wallDetect.isEnabled() && hasWall(mc, player, le)) continue;

            candidates.add(le);
        }

        if (candidates.isEmpty()) return null;

        // Focus: prefer the locked target if it's still valid
        if (focus.isEnabled() && target != null && candidates.contains(target)) {
            return target;
        }

        // Otherwise pick closest
        candidates.sort(Comparator.comparingDouble(e -> e.distanceTo(player)));
        return candidates.get(0);
    }

    // ─── Wall detection via raycast ───────────────────────────────────
    private boolean hasWall(MinecraftClient mc, PlayerEntity player, LivingEntity entity) {
        Vec3d eyePos  = player.getCameraPosVec(1.0f);
        Vec3d targetPos = entity.getCameraPosVec(1.0f);
        HitResult hit = mc.world.raycast(new RaycastContext(
                eyePos, targetPos,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                player
        ));
        return hit.getType() != HitResult.Type.MISS;
    }

    // ─── Rotation math ───────────────────────────────────────────────
    private float[] calculateRotation(PlayerEntity player, LivingEntity target) {
        Vec3d playerEye = player.getCameraPosVec(1.0f);
        Vec3d targetCenter = target.getBoundingBox().getCenter();

        double dx = targetCenter.x - playerEye.x;
        double dy = targetCenter.y - playerEye.y;
        double dz = targetCenter.z - playerEye.z;

        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw   = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        return new float[]{ yaw, MathHelper.clamp(pitch, -90f, 90f) };
    }

    private float lerpAngle(float current, float target, float t) {
        float delta = MathHelper.wrapDegrees(target - current);
        return current + delta * t;
    }

    private float quantise(float angle) {
        // Round to nearest 0.05° to match vanilla precision
        return Math.round(angle / 0.05f) * 0.05f;
    }

    // ─── Rotation packet ─────────────────────────────────────────────
    private void sendRotation(MinecraftClient mc, float yaw, float pitch, boolean onGround) {
        mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, onGround, false)
        );
    }

    // ─── Shield helpers ───────────────────────────────────────────────
    private boolean isUsingShield(LivingEntity entity) {
        return entity.isBlocking();
    }

    private void swapToAxe(MinecraftClient mc, PlayerEntity player) {
        if (wasAxe) return; // already swapped
        int axeSlot = findAxeSlot(player);
        if (axeSlot == -1) return;
        prevSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = axeSlot;
        wasAxe = true;
    }

    private void restorePrevSlot() {
        if (prevSlot == -1 || !wasAxe) return;
        MinecraftClient mc = BeretonClient.mc();
        if (mc.player == null) return;
        mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
        wasAxe   = false;
    }

    private int findAxeSlot(PlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            Item item = player.getInventory().getStack(i).getItem();
            if (item instanceof AxeItem) return i;
        }
        return -1;
    }

    // ─── Weapon check ─────────────────────────────────────────────────
    private boolean isWeapon(Item item) {
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem;
    }

    // ─── Track: set player move yaw ───────────────────────────────────
    // We store our desired movement direction; MixinClientPlayerEntity reads this
    private static float desiredMoveYaw = Float.NaN;

    private void setMoveYaw(PlayerEntity player, float yaw) {
        desiredMoveYaw = yaw;
    }

    public static float getDesiredMoveYaw() { return desiredMoveYaw; }
    public static void  clearDesiredMoveYaw() { desiredMoveYaw = Float.NaN; }
}
