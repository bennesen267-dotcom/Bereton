package com.bereton.modules.combat;

import com.bereton.BeretonClient;
import com.bereton.module.Category;
import com.bereton.module.Module;
import com.bereton.module.settings.BooleanSetting;
import com.bereton.module.settings.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;

/**
 * AutoPotions — throws splash potions automatically.
 *
 * Handles: Speed, Strength, Regeneration, Instant Healing.
 * Instant Heal has a configurable health threshold.
 * Each potion type is individually toggleable.
 */
public class AutoPotions extends Module {

    public final BooleanSetting speed =
            register(new BooleanSetting("Speed", true));
    public final BooleanSetting strength =
            register(new BooleanSetting("Strength", true));
    public final BooleanSetting regen =
            register(new BooleanSetting("Regeneration", true));
    public final BooleanSetting instantHeal =
            register(new BooleanSetting("Instant Heal", true));

    // Health threshold below which we throw Instant Heal (half-hearts)
    public final NumberSetting healThreshold =
            register(new NumberSetting("Heal Health", 12.0, 1.0, 20.0, 0.5));

    // Ticks between throws to avoid spam flags
    private int throwCooldown = 0;
    private static final int THROW_DELAY = 5; // ticks

    public AutoPotions() {
        super("Auto Potions", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = BeretonClient.mc();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        ClientPlayerEntity player = mc.player;

        if (throwCooldown > 0) {
            throwCooldown--;
            return;
        }

        // Instant Heal — highest priority
        if (instantHeal.isEnabled() && player.getHealth() < healThreshold.getValue()) {
            if (tryThrow(mc, player, "healing")) return;
        }

        // Regeneration — throw if no regen effect active
        if (regen.isEnabled() && !player.hasStatusEffect(StatusEffects.REGENERATION)) {
            if (tryThrow(mc, player, "regeneration")) return;
        }

        // Speed — throw if no speed effect active
        if (speed.isEnabled() && !player.hasStatusEffect(StatusEffects.SPEED)) {
            if (tryThrow(mc, player, "swiftness")) return;
        }

        // Strength — throw if no strength effect active
        if (strength.isEnabled() && !player.hasStatusEffect(StatusEffects.STRENGTH)) {
            if (tryThrow(mc, player, "strength")) return;
        }
    }

    /**
     * Finds a splash potion matching the given potion name in the hotbar,
     * swaps to it, throws it, then restores the previous slot.
     *
     * @param potionName  The last segment of the potion's registry ID (e.g. "healing", "swiftness")
     * @return true if a potion was found and thrown
     */
    private boolean tryThrow(MinecraftClient mc, ClientPlayerEntity player, String potionName) {
        int slot = findSplashPotion(player, potionName);
        if (slot == -1) return false;

        int prevSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = slot;

        // Look slightly downward so the potion hits the ground under us
        float prevPitch = player.getPitch();
        player.setPitch(85.0f);

        mc.interactionManager.interactItem(player, Hand.MAIN_HAND);

        player.setPitch(prevPitch);
        player.getInventory().selectedSlot = prevSlot;

        throwCooldown = THROW_DELAY;
        return true;
    }

    /**
     * Scans hotbar slots 0–8 for a SplashPotionItem whose potion effect
     * matches the requested type.
     */
    private int findSplashPotion(ClientPlayerEntity player, String potionName) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            if (!(stack.getItem() instanceof SplashPotionItem)) continue;

            Potion potion = PotionUtil.getPotion(stack);
            String id = Registries.POTION.getId(potion).getPath(); // e.g. "strong_swiftness"

            if (id.contains(potionName)) return i;
        }
        return -1;
    }
}
