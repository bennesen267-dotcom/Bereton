package com.bereton.modules.combat;

import com.bereton.BeretonClient;
import com.bereton.module.Category;
import com.bereton.module.Module;
import com.bereton.module.settings.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;

/**
 * AutoTotem — replaces the offhand totem when health drops below threshold.
 *
 * Bypass technique:
 *  - Direct ClickSlotC2SPacket manipulation — no inventory-open animation.
 *  - Two-packet swap: pick up totem from hotbar/inventory → place in offhand (slot 45).
 *  - ElytraHealth: when wearing elytra, the threshold is separate because
 *    kinetic damage from elytra wall-hits is near-instant and bypasses normal
 *    health checks — we use a slightly higher threshold for elytra wearers.
 *  - Delay: configurable ticks between re-equip attempts to avoid flagging
 *    anti-cheats that track swap frequency (e.g. Matrix, Spartan, Grim).
 */
public class AutoTotem extends Module {

    // Normal health threshold (half-hearts, 1.0 = half a heart)
    public final NumberSetting health =
            register(new NumberSetting("Health", 8.0, 1.0, 20.0, 0.5));

    // Separate threshold when wearing elytra (kinetic damage is faster)
    public final NumberSetting elytraHealth =
            register(new NumberSetting("Elytra Health", 14.0, 1.0, 20.0, 0.5));

    // Ticks between swap attempts
    public final NumberSetting delay =
            register(new NumberSetting("Delay", 1.0, 0.0, 10.0, 1.0));

    // Offhand slot index in the screen handler (consistent across versions)
    private static final int OFFHAND_SLOT = 45;

    private int cooldown = 0;

    public AutoTotem() {
        super("Auto Totem", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = BeretonClient.mc();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        ClientPlayerEntity player = mc.player;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        // Already holding a totem in offhand → nothing to do
        ItemStack offhand = player.getOffHandStack();
        if (offhand.getItem() == Items.TOTEM_OF_UNDYING) return;

        // Determine the active health threshold
        boolean wearingElytra = player.getInventory().getArmorStack(2).getItem() == Items.ELYTRA;
        double threshold = wearingElytra ? elytraHealth.getValue() : health.getValue();

        if (player.getHealth() > threshold) return;

        // Find a totem in the inventory
        int totemSlot = findTotemSlot(player.getInventory());
        if (totemSlot == -1) return;

        // Perform the swap via raw packets — no screen needs to be open
        swapToOffhand(mc, player, totemSlot);

        cooldown = delay.getInt();
    }

    /**
     * Two-packet sequence:
     *  1. Left-click the totem slot to pick it up (cursor holds the stack).
     *  2. Left-click offhand slot (45) to place it.
     *
     * We use the player's screenHandler stateId and revision counters so the
     * server accepts the packets without a sync mismatch.
     */
    private void swapToOffhand(MinecraftClient mc, ClientPlayerEntity player, int invSlot) {
        var handler = player.playerScreenHandler;
        int syncId   = handler.syncId;
        int revision = handler.nextRevision();

        // Convert inventory slot index to screen-handler slot index.
        // Inventory slots 0-8 (hotbar) map to screen slots 36-44.
        // Inventory slots 9-35 map to screen slots 9-35.
        int screenSlot;
        if (invSlot < 9) {
            screenSlot = 36 + invSlot; // hotbar
        } else {
            screenSlot = invSlot;      // main inventory
        }

        ItemStack totem = handler.getSlot(screenSlot).getStack().copy();
        ItemStack offhandStack = handler.getSlot(OFFHAND_SLOT).getStack().copy();

        // Packet 1: pick up from inventory slot
        mc.getNetworkHandler().sendPacket(new ClickSlotC2SPacket(
                syncId, revision, screenSlot, 0,
                SlotActionType.PICKUP,
                totem,
                java.util.List.of()
        ));

        // Packet 2: place into offhand slot
        mc.getNetworkHandler().sendPacket(new ClickSlotC2SPacket(
                syncId, revision + 1, OFFHAND_SLOT, 0,
                SlotActionType.PICKUP,
                ItemStack.EMPTY,
                java.util.List.of()
        ));

        // Sync client-side so the next tick sees the correct state
        handler.getSlot(screenSlot).setStack(ItemStack.EMPTY);
        handler.getSlot(OFFHAND_SLOT).setStack(totem);
    }

    /**
     * Searches hotbar first (slots 0–8) then main inventory (slots 9–35).
     * Returns inventory slot index, or -1 if not found.
     */
    private int findTotemSlot(PlayerInventory inv) {
        // Hotbar first — fastest access
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        // Main inventory
        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        return -1;
    }
}
