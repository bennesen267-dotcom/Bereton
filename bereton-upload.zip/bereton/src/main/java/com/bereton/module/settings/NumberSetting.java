package com.bereton.module.settings;

public class NumberSetting extends Setting<Double> {

    public final double min;
    public final double max;
    public final double step;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    @Override
    public void setValue(Double value) {
        this.value = Math.max(min, Math.min(max, value));
    }

    public float getFloat() { return value.floatValue(); }
    public int   getInt()   { return value.intValue(); }
}
